const players = [
  {
    name: "MS Dhoni",
    age: 42,
    image: "57.jpg",
    specialty: "Captain & Wicketkeeper"
  },
  {
    name: "Ravindra Jadeja",
    age: 35,
    image: "46.jpg",
    specialty: "All-rounder"
  },
  {
    name: "Ruturaj Gaikwad",
    age: 27,
    image: "102.jpg",
    specialty: "Opening Batsman"
  },
  {
    name: "Matheesha Pathirana",
    age: 23,
    image: "1014.jpg",
    specialty: "Fast Bowler"
  }
];

const galleryImages = [
  {
    url: "csk 2023.webp",
    caption: "CSK IPL 2023 Champions"
  },
  {
    url: "csk2021.webp",
    caption: "Team Celebrations"
  },
  {
    url: "captaincool.avif",
    caption: "Captain Cool with Trophy"
  },
  {
    url: "csk squad.avif",
    caption: "CSK Squad"
  }
];

// Initialize theme
const initTheme = () => {
  const themeToggle = document.getElementById('theme-toggle');
  themeToggle.addEventListener('click', () => {
    document.body.dataset.theme = document.body.dataset.theme === 'dark' ? 'light' : 'dark';
    themeToggle.textContent = document.body.dataset.theme === 'dark' ? '☀️' : '🌙';
  });
};

// Create player cards
const createPlayerCards = () => {
  const playersGrid = document.getElementById('players-grid');
  players.forEach(player => {
    const playerCard = document.createElement('div');
    playerCard.className = 'player-card';
    playerCard.innerHTML = `
      <img src="${player.image}" alt="${player.name}" class="player-image">
      <div class="player-info">
        <h3 class="player-name">${player.name}</h3>
        <p>Age: ${player.age}</p>
        <p>Specialty: ${player.specialty}</p>
      </div>
    `;
    playersGrid.appendChild(playerCard);
  });
};

// Create gallery
const createGallery = () => {
  const galleryGrid = document.getElementById('gallery-grid');
  galleryImages.forEach(image => {
    const galleryItem = document.createElement('div');
    galleryItem.className = 'gallery-item';
    galleryItem.innerHTML = `
      <img src="${image.url}" alt="${image.caption}">
      <div class="gallery-caption">${image.caption}</div>
    `;
    galleryGrid.appendChild(galleryItem);
  });
};

// Initialize menu
const initMenu = () => {
  const menuToggle = document.querySelector('.menu-toggle');
  const menuItems = document.querySelector('.menu-items');
  
  menuToggle.addEventListener('click', () => {
    menuItems.classList.toggle('show');
  });

  // Close menu when clicking a link
  document.querySelectorAll('.menu-items a').forEach(link => {
    link.addEventListener('click', () => {
      menuItems.classList.remove('show');
    });
  });
};

// Smooth scroll functionality
const initSmoothScroll = () => {
  const scrollUp = document.querySelector('.scroll-up');
  scrollUp.addEventListener('click', () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  });

  // Smooth scroll for menu links
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      document.querySelector(this.getAttribute('href')).scrollIntoView({
        behavior: 'smooth'
      });
    });
  });
};

// Initialize the page
document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  createPlayerCards();
  createGallery();
  initMenu();
  initSmoothScroll();
});